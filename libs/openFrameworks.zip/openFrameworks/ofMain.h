#ifndef OF_MAIN_H
#define OF_MAIN_H

//--------------------------
// get the core in:
#include "ofCore.h"


#endif
